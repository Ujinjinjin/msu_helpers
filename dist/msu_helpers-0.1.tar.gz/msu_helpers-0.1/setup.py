from setuptools import setup

setup(
    name='msu_helpers',
    packages=['msu_helpers'],
    description='Package created for the university project to store common applications logic in one place. I am pretty sure that you do not need it',
    version='0.1',
    url='',  # TODO Paste here git link
    author='Ujinjinjin',
    author_email='ujinjinjin@outlook.com ',
    keywords=['pip','msu_sqluniversity']
    )
